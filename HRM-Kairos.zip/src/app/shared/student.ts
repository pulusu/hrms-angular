export class Student {
   _id: String;
   student_name: String;
   student_email: String;
   section: String;
   subjects: Array<string>;
   dob: Date;
   gender: String;
}