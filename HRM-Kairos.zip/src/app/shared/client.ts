export class Client {
    _id: String;
    client_name: String;
    website: String;
    location:String;
    primary_email: String;
    address:String;
    Contact_Person_Name_1: String;
    Mobile_Number_1: String;
    Email_id_1:String;
    aggrimentfile:string;
    Location_1:String;
 }