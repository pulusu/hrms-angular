import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router} from '@angular/router';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-add-runs',
  templateUrl: './add-runs.component.html',
  styleUrls: ['./add-runs.component.css']
})
export class AddRunsComponent implements OnInit {
	currentTrackUser;
isLoadingResults;
Message;
 tempteam_Result;
  carrier_Result;
  tempEmp_Result;
   emp_Result;
runsForm: FormGroup;
  constructor(private router: Router, private formBuilder: FormBuilder,private http: HttpClient) { 
         this.teamsSelect();
         this.EmployeeSelect();
  }

  ngOnInit() {
	  this.loadScript('../assets/bundles/libscripts.bundle.js');
    this.loadScript('../assets/bundles/vendorscripts.bundle.js');
    this.loadScript('../assets/bundles/datatablescripts.bundle.js');
    this.loadScript('../assets/vendor/sweetalert/sweetalert.min.js');
    this.loadScript('../assets/bundles/mainscripts.bundle.js');
    this.loadScript('../assets/js/pages/tables/jquery-datatable.js');
    this.loadScript('../assets/js/pages/ui/dialogs.js');
    //this.carrierSelect();
   // this.headSelect();
 

       // Start Form Validations //
   this.currentTrackUser = JSON.parse(localStorage.getItem('hrms-kairos-currentTrackUser'));

   this.runsForm = this.formBuilder.group({
	 'team_id' : [null, Validators.required],
	 'member_id' : [null, Validators.required],
     'emp_accuracy' : [null, Validators.required],
     'emp_submissions' : [null, Validators.required],
     'emp_closures' : [null, Validators.required],
     'emp_compliance' : [null, Validators.required],
     'emp_bonus' : [null, Validators.required],
     'total_score' : [null],
     'created_by' : [null]
   });
  }

    public loadScript(url: string) {
    const body = <HTMLDivElement> document.body;
    const script = document.createElement('script');
    script.innerHTML = '';
    script.src = url;
    script.async = false;
    script.defer = true;
    body.appendChild(script);
  }
  onFormSubmit(form:NgForm) {
    this.runsForm.value.created_by=this.currentTrackUser._id;
    console.log('this.runsForm.value',this.runsForm.value)

    console.log(this.runsForm.value.team_head_name._id)
    if(this.runsForm.value.team_head_name._id == undefined){

      this.runsForm.value.team_head_name = '';
      this.Message="Please select valid employee";
	 // this.team_head_name.reset();
    }else{
            this.runsForm.value.department_head=this.runsForm.value.team_head_name._id;
      this.http.post(`${environment.api_url}`+`${environment.emp_teams_add}`, this.runsForm.value).subscribe((datasubmit:any)=>{
      this.isLoadingResults = false;            
      this.Message="Team added Successfully";
		  setTimeout(()=>{
		  this.Message = null;
      this.router.navigate(['/teams-list']);	 
			},500); 
			
        }, (err) => {
          console.log(err);
          this.isLoadingResults = false;
        });

    }
      
    
  }
  
  teamsSelect(){
  let obs=this.http.get(`${environment.api_url}`+`${environment.emp_teams}`)
  obs.subscribe((carrier_Result:any)=>{ 
    this.tempteam_Result = carrier_Result;
    console.log('this.tempteam_Result',this.tempteam_Result)
    this.suggest_carrier('');
  });
}
suggest_carrier(team_name){
  this.carrier_Result = this.tempteam_Result.filter(response => response.team_name.toLowerCase().startsWith(team_name.toLowerCase())).slice(0, 3);
}  
displayFn(country): string {
  return country ? country.team_name : country;
}   
 
displayFnemp(emp): string {
  return emp ? emp.employee_name : emp;
}  
EmployeeSelect(){
  let obs=this.http.get(`${environment.api_url}`+`${environment.employees_list}`)
  obs.subscribe((emp_Result:any)=>{ 
    this.tempEmp_Result = emp_Result;
    console.log('this.tempEmp_Result',this.tempEmp_Result)
    this.suggest_manager('');
  });
}
suggest_manager(employee_name){
  this.emp_Result = this.tempEmp_Result.filter(response => response.employee_name.toLowerCase().startsWith(employee_name.toLowerCase())).slice(0, 3);
}
}
