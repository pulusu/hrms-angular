import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team-member-details',
  templateUrl: './team-member-details.component.html',
  styleUrls: ['./team-member-details.component.css']
})
export class TeamMemberDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
