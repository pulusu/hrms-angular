import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute} from '@angular/router';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { environment } from '../../../environments/environment';

export interface locgroup{
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-emp-data-edit',
  templateUrl: './emp-data-edit.component.html',
  styleUrls: ['./emp-data-edit.component.css']
})
export class EmpDataEditComponent implements OnInit {

	currentTrackUser;
isLoadingResults;
Message;
empForm: FormGroup;
tempdeparment_Result;
carrier_Result;
locations: locgroup[] = [
    {value: '', viewValue: 'Select Location'},
    {value: 'Kairos USA', viewValue: 'Kairos USA'},
    {value: 'Kairos Hyderabad', viewValue: 'Kairos Hyderabad'},
    {value: 'Kairos Vizag', viewValue: 'Kairos Vizag'},
    {value: 'Solunus Hyderabad', viewValue: 'Solunus Hyderabad'},
    {value: 'Solunus Dallas', viewValue: 'Solunus Dallas'}
    
  ];

  constructor(private router: Router, private actRoute: ActivatedRoute,
    private formBuilder: FormBuilder, private http: HttpClient) {
      this.departmentsSelect();
      
    var id = this.actRoute.snapshot.paramMap.get('id');
    this.http.get(`${environment.api_url}`+`${environment.emp_data_details}`+'/'+id).subscribe((datareturn:any)=>{
      console.log('emp_data_details',datareturn)
      var data =datareturn.employee_department[0];
      this.empForm = this.formBuilder.group({
        'emp_id' : [datareturn.emp_id, Validators.required],
        'emp_name' : [datareturn.emp_name, Validators.required],
          'emp_designation' : [datareturn.emp_designation, Validators.required],
          'employee_department' : ["5f05809a213460143071896b", Validators.required],
          'emp_doj' : [datareturn.emp_doj, Validators.required],
          'emp_mobile' : [datareturn.emp_mobile, Validators.required],
          'emp_official_email' : [datareturn.emp_official_email, Validators.required],
          'emp_actual_dob' : [datareturn.emp_actual_dob, Validators.required],
          'emp_dob_records' : [datareturn.emp_dob_records, Validators.required],
          'emp_wedding_anniversary' : [datareturn.emp_wedding_anniversary, Validators.required],
          'emp_job_location' : [datareturn.emp_job_location, Validators.required],
          'emp_report_manager_mail' : [datareturn.emp_report_manager_mail, Validators.required]
        });
      
     }); 
      this.departmentsSelect();
  }

  ngOnInit() {
	this.loadScript('../assets/bundles/libscripts.bundle.js');
    this.loadScript('../assets/bundles/vendorscripts.bundle.js');
    this.loadScript('../assets/bundles/datatablescripts.bundle.js');
    this.loadScript('../assets/vendor/sweetalert/sweetalert.min.js');
    this.loadScript('../assets/bundles/mainscripts.bundle.js');
    this.loadScript('../assets/js/pages/tables/jquery-datatable.js');
    this.loadScript('../assets/js/pages/ui/dialogs.js');
	
	 this.currentTrackUser = JSON.parse(localStorage.getItem('hrms-kairos-currentTrackUser'));

   this.empForm = this.formBuilder.group({
	 'emp_id' : [null, Validators.required],
	 'emp_name' : [null, Validators.required],
     'emp_designation' : [null, Validators.required],
     'employee_department' : [null, Validators.required],
     'emp_doj' : [null, Validators.required],
     'emp_mobile' : [null, Validators.required],
     'emp_official_email' : [null, Validators.required],
     'emp_actual_dob' : [null, Validators.required],
     'emp_dob_records' : [null, Validators.required],
     'emp_wedding_anniversary' : [null, Validators.required],
     'emp_job_location' : [null, Validators.required],
     'emp_report_manager_mail' : [null, Validators.required],
     'created_by' : [null]
   });
  }
   public loadScript(url: string) {
    const body = <HTMLDivElement> document.body;
    const script = document.createElement('script');
    script.innerHTML = '';
    script.src = url;
    script.async = false;
    script.defer = true;
    body.appendChild(script);
  }
  
  
  onFormSubmit(form:NgForm) {
    var id = this.actRoute.snapshot.paramMap.get('id');
    this.empForm.value.created_by=this.currentTrackUser._id;
    if(this.empForm.value.employee_department._id == undefined){

      this.empForm.value.employee_department = '';
      this.Message="Please select valid Department";
  	 
    }else{
            this.empForm.value.employee_department=this.empForm.value.employee_department._id;
      this.http.put(`${environment.api_url}`+`${environment.emp_data_update}`+'/'+id, this.empForm.value).subscribe((datasubmit:any)=>{
      this.isLoadingResults = false;            
      this.Message="Employee added Successfully";
		  setTimeout(()=>{
		  this.Message = null;
      this.router.navigate(['/emp-data-list']);	 
			},500); 
			
        }, (err) => {
          console.log(err);
          this.isLoadingResults = false;
        });

    }
      
    
  }
  departmentsSelect(){
  let obs=this.http.get(`${environment.api_url}`+`${environment.departments_list}`)
  obs.subscribe((carrier_Result:any)=>{ 
    this.tempdeparment_Result = carrier_Result;
    console.log('this.tempdeparment_Result',this.tempdeparment_Result)
    this.suggest_carrier('');
  });
}
suggest_carrier(department_name){
  this.carrier_Result = this.tempdeparment_Result.filter(response => response.department_name.toLowerCase().startsWith(department_name.toLowerCase())).slice(0, 3);
}
displayFn(country): string {
  return country ? country.department_name : country;
}  


}

