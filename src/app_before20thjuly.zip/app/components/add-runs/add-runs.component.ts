import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-runs',
  templateUrl: './add-runs.component.html',
  styleUrls: ['./add-runs.component.css']
})
export class AddRunsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
