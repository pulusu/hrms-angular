export class User {
    _id: String;
    user_name: String;
    user_email: String;
    password: String;
    user_type: String;
    userpicture: String;
}