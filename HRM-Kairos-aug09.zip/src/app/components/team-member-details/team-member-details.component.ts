import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router,ActivatedRoute} from '@angular/router';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-team-member-details',
  templateUrl: './team-member-details.component.html',
  styleUrls: ['./team-member-details.component.css']
})
export class TeamMemberDetailsComponent implements OnInit {

  team_details;
  teamid;
  isLoadingResults = false;

  constructor(private router: Router,private activatedRoute: ActivatedRoute, private _formBuilder: FormBuilder,private http: HttpClient) {
    console.log("routes");
    console.log(activatedRoute.snapshot.url); // array of states
    this.teamid=activatedRoute.snapshot.url[1].path;
    console.log(activatedRoute.snapshot.url[0].path); 
    this.onloadEmployee();

   } 
  ngOnInit() {
  }
  onloadEmployee() {
    this.http.get(`${environment.api_url}`+`${environment.ipl_team_membeer_details}`+'/'+this.teamid).subscribe((form:any)=>{
       this.team_details=form;
       console.log('teams-memberss',form)
            }, (err) => {
          console.log(err);
          this.isLoadingResults = false;
        });
  }
}
