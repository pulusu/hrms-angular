import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profiles-list',
  templateUrl: './profiles-list.component.html',
  styleUrls: ['./profiles-list.component.css']
})
export class ProfilesListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
